hit_finally = False

try:
    pass
finally:
    hit_finally = True

___assertTrue(hit_finally)
