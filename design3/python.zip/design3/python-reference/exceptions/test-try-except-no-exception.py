hit_except = False

try:
    pass
except:
    hit_except = True

___assertFalse(hit_except)
