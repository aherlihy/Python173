d = {}
___assertEqual(set(d.items()), set())

d = {1:2}
___assertEqual(set(d.items()), {(1, 2)})
___assertRaises(TypeError, d.items, None)
