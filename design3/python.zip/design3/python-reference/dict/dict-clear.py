d = {1:1, 2:2, 3:3}
print(d)
d.clear()
print(d)
___assertEqual(d, {})

#___assertRaises(TypeError, d.clear, None)
