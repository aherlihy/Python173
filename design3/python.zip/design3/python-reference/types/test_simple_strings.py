if len('') != 0: raise Exception('len(\'\')')
if len('a') != 1: raise Exception('len(\'a\')')
if len('abcdef') != 6: raise Exception('len(\'abcdef\')')
