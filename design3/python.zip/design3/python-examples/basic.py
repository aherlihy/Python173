x=4
print(x)

def f(x):
    y=4
    return x

print(f(5))

def g(x):
    x

print(g(5))

___assertTrue(1)
___assertTrue(False)
