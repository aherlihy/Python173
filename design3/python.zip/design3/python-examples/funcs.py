x=4
f=lambda x: x
print(f(4))
