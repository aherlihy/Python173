if 0:
    print(0)
else:
    print(1)

if True:
    print(1)
else:
    print(0)

if False:
    print(0)
else:
    print(1)

x=()
    
if x:
    print(0)
else:
    print(1)

if (1,2):
    print(1)
else:
    print(0)

if None:
    print(0)
else:
    print(1)
