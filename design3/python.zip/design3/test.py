d ={}
___assertRaises(TypeError, d.get)
___assertRaises(TypeError, d.get, None, None, None)
